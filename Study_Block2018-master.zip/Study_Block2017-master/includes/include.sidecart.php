<div class="sidecart">

	<h2 class="border-top"><a href="shop-cart.php">Cart Summary</a></h2>

	<a href="#" class="button full black">View Cart</a>

	<p class="vertical-divider">or</p>

	<a href="#" class="button black full">Checkout</a>
	<p class="desc">Payments are securely processed via Paypal.</p>

</div><!-- // .sidecart -->